import os
import sys

print(os)
print(sys)

a = "python"

b = "ssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssss"

frutas = [
    "pera",
    "maçã",
    "laranja",
    "uva",
    "melão",
    "morango",
    "abacate",
    "banana",
    "carambola",
    "pessego",
    "tamara",
    "melancia",
]

carros = ["ferrari", "brasilia", "gol", "up"]
