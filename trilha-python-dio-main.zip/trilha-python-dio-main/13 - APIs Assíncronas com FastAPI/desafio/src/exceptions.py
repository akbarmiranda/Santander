class AccountNotFoundError(Exception):
    pass


class BusinessError(Exception):
    pass
